package examen;

import capaPressentacion.inicio;

public class Examen {

    public static void main(String[] args) {
        inicio i = new inicio();
        i.setVisible(true);
        
        
    }
    
}
