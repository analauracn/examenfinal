package capaLogica;

import capaDatos.datosMarcas;
import capaDatos.datosModelos;
import java.sql.ResultSet;

public class logicaModelos {
    datosModelos modelo = new datosModelos();
    
    public ResultSet getModelos(){
        ResultSet m = modelo.selectModelos();
        return m;
    }
    
    public void setModelos(String modelo){
        this.modelo.insertModelos(modelo);
    }
    
    public void borrarModelos(int id){
        modelo.deleteModelo(id);
    }
    
    public void actualizarModelos(int id, String nombre){
        modelo.updateModelos(id, nombre);
    }    
}
