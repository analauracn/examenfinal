package capaLogica;

import capaDatos.datosVehiculos;
import java.sql.ResultSet;

public class logicaVehiculos {
    datosVehiculos v = new datosVehiculos();
    
    public ResultSet getVehiculos(){
        ResultSet vehiculos = v.selectVehiculos();
        return vehiculos;
    }
    
    public void setVehiculos(String vehiculo, String modelo, String marca){
        v.insertVehiculos(vehiculo, modelo, marca);
    }
    
    public void borrarVehiculos(int id){
        v.deleteVehiculos(id);
    }
    
    public void actualizarVehiculos(int id, String nombre, String modelo, String marca){
        v.updateVehiculos(id, nombre, modelo, marca);
    }
}
