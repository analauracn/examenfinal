package capaLogica;

import capaDatos.datosMarcas;
import java.sql.ResultSet;

public class logicaMarcas {

    datosMarcas marca = new datosMarcas();
    
    public ResultSet getMarcas(){
        ResultSet marcas = marca.selectMarcas();
        return marcas;
    }
    
    public void setMarcas(String marca){
        this.marca.insertMarcas(marca);
    }
    
    public void borrarMarcas(int id){
        marca.deleteMarcas(id);
    }
    
    public void actualizarMarca(int id, String nombre){
        marca.updateMarcas(id, nombre);
    }

}
