package capaDatos;

import java.sql.Statement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public class datosMarcas extends Conexion{
    
    Statement s;
    
    public datosMarcas(){
        
    }
    
    public ResultSet selectMarcas(){
        ResultSet rs = null;
        try {
            this.s = conn.createStatement();
            rs = this.s.executeQuery("SELECT * FROM Marcas");
        } catch (SQLException ex) {
            Logger.getLogger(datosMarcas.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("llego");

        return rs;
    }
    
    public void insertMarcas(String marca){
        
        try {

            this.s = conn.createStatement();

            this.s.executeUpdate(
                    "INSERT INTO Marcas ("
                  + "nombreMarcas"
                  + ") VALUES ('"
                  + marca + "')");
            
            
        } catch(Exception e) {
            System.out.print(e);
        }
        
    }
    
    public void deleteMarcas(int id){
        try {
            this.s = conn.createStatement();
             this.s.executeUpdate("DELETE FROM Marcas WHERE idMarcas = " + id);
        } catch (SQLException ex) {
            Logger.getLogger(datosMarcas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void updateMarcas(int id, String nombre){
        try {
            this.s = conn.createStatement();
            this.s.executeUpdate("UPDATE Marcas SET nombreMarcas = '" + nombre + "' WHERE idMarcas = " + id); 
        } catch (SQLException ex) {
            Logger.getLogger(datosMarcas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
