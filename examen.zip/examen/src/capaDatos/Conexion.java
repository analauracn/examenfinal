package capaDatos;

import java.sql.*;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexion {
    private String db_name = "ExamenFinalProgra2B_1";
    private String db_user = "root";
    private String db_pass = "";
    private String db_url  = "jdbc:mysql://localhost:3306/"+db_name+"?useUnicode=true&use"
                                + "JDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&"
                                + "serverTimezone=UTC";
    
    Connection conn;
    
    public Conexion(){
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            conn = DriverManager.getConnection(this.db_url,this.db_user,this.db_pass);
            if(conn!=null){
                System.out.println("Conexión Exitosa a la BD" + this.db_name);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
}
