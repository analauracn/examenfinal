package capaDatos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class datosVehiculos extends Conexion{
    Statement s;
    
    public datosVehiculos(){
        
    }
    
    public ResultSet selectVehiculos(){
        ResultSet rs = null;
        try {
            this.s = conn.createStatement();
            rs = this.s.executeQuery("SELECT * FROM Vehiculos");
        } catch (SQLException ex) {
            Logger.getLogger(datosMarcas.class.getName()).log(Level.SEVERE, null, ex);
        }

        return rs;
    }
    
    public void insertVehiculos(String vehiculo, String modelo, String marca){
        
        try {

            this.s = conn.createStatement();

            this.s.executeUpdate(
                    "INSERT INTO Vehiculos ("
                  + "tipoVehiculo, modelo, marca"
                  + ") VALUES ('"
                  + vehiculo + "', '" + modelo + "', '" + marca + "')");
            
            
        } catch(Exception e) {
            System.out.print(e);
        }
        
    }
    
    public void deleteVehiculos(int id){
        try {
            this.s = conn.createStatement();
             this.s.executeUpdate("DELETE FROM Vehiculos WHERE idVehiculo = " + id);
        } catch (SQLException ex) {
            Logger.getLogger(datosMarcas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void updateVehiculos(int id, String nombre, String modelo, String marca){
        try {
            this.s = conn.createStatement();
            this.s.executeUpdate("UPDATE Vehiculos SET tipoVehiculo = '" + nombre + "', modelo = '" + modelo + "', marca = '" + marca + "' WHERE idVehiculo = " + id); 
        } catch (SQLException ex) {
            Logger.getLogger(datosMarcas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
