package capaDatos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class datosModelos extends Conexion {
        Statement s;
    
    public datosModelos(){
        
    }
    
    public ResultSet selectModelos(){
        ResultSet rs = null;
        try {
            this.s = conn.createStatement();
            rs = this.s.executeQuery("SELECT * FROM Modelos");
        } catch (SQLException ex) {
            Logger.getLogger(datosMarcas.class.getName()).log(Level.SEVERE, null, ex);
        }

        return rs;
    }
    
    public void insertModelos(String modelo){
        
        try {

            this.s = conn.createStatement();

            this.s.executeUpdate(
                    "INSERT INTO Modelos ("
                  + "nombreModelos"
                  + ") VALUES ('"
                  + modelo + "')");
            
            
        } catch(Exception e) {
            System.out.print(e);
        }
        
    }
    
    public void deleteModelo(int id){
        try {
            this.s = conn.createStatement();
             this.s.executeUpdate("DELETE FROM Modelos WHERE idModelos = " + id);
        } catch (SQLException ex) {
            Logger.getLogger(datosMarcas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void updateModelos(int id, String nombre){
        try {
            this.s = conn.createStatement();
            this.s.executeUpdate("UPDATE Modelos SET nombreModelos = '" + nombre + "' WHERE idModelos = " + id); 
        } catch (SQLException ex) {
            Logger.getLogger(datosMarcas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
